
TslGame-WindowsNoEditor1a.pak: no recoil, no spread, golden players, no grass, no bush
TslGame-WindowsNoEditor2a.pak: no recoil, no spread, no grass, no bush
TslGame-WindowsNoEditor3a.pak: no recoil, no spread, no grass
TslGame-WindowsNoEditor4a.pak: no recoil, no spread
TslGame-WindowsNoEditor5a.pak: no recoil (it shakes the weapon)
TslGame-WindowsNoEditor6a.pak: no recoil, no grass (it shakes the weapon)